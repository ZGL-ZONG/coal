import torch
import torch.nn as nn

class SEBlock(nn.Module):
    def __init__(self,in_channels,ratio):
        super(SEBlock, self).__init__()
        middle_channels=in_channels//ratio
        self.squeeze=nn.AdaptiveAvgPool2d(1)
        self.excitation = nn.Sequential(
            nn.Conv2d(in_channels, middle_channels, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(middle_channels, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        # Squeeze phase
        squeezed = self.squeeze(x)
        print("Squeezed shape:", squeezed.shape)
        # Excitation phase
        weights = self.excitation(squeezed)
        print("Excitation weights shape:", weights.shape)
        # Re-calibration phase
        output = x * weights
        print("Output shape:", output.shape)
        return output

if __name__ == '__main__':
    model=SEBlock(64,8)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    input_tensor=torch.randn(1,64,224,224).to(device)
    output_tensor=model(input_tensor)
import torch
import torch.nn as nn

class SEBlock(nn.Module):
    def __init__(self,in_channels,ratio):
        super(SEBlock, self).__init__()
        middle_channels=in_channels//ratio
        self.squeeze=nn.AdaptiveAvgPool2d(1)
        self.excitation = nn.Sequential(
            nn.Conv2d(in_channels, middle_channels, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(middle_channels, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        # Squeeze phase
        squeezed = self.squeeze(x)
        print("Squeezed shape:", squeezed.shape)
        # Excitation phase
        weights = self.excitation(squeezed)
        print("Excitation weights shape:", weights.shape)
        # Re-calibration phase
        output = x * weights
        print("Output shape:", output.shape)
        return output

if __name__ == '__main__':
    model=SEBlock(64,8)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    input_tensor=torch.randn(1,64,224,224).to(device)
    output_tensor=model(input_tensor)
